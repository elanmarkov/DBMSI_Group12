# DBMSI_Group12
CSE 510 Group 12 Project
Group Members:  
Elan Markov  
Simarpreet Kaur  
Prachi Sharma  
Jayanth Kumar Melinavolagerehalli Jayaramaiah  
Harshdeep Singh Sandhu  
Priyekant Aghi  
Shalmali Bhoir  

Current project completed up to phase 2.

To run the old features:  
Use:  
make db; make test  
as for the phase 1 items.

The new graph tests will run with make test with the rest of the old tests.

To run just the new tests: run bash command:  
make db; make graphtest  
in the src folder.

The graphtest implements six queries:  
Batch Node Insert  
Batch Edge Insert  
Batch Node Delete  
Batch Edge Delete  
Node Query  
Edge Query  

The input format is provided in the report and in the console menu for the test (same as in the project specification).

Must have Java 1.7 or newer and JDK installed to compile and run.
