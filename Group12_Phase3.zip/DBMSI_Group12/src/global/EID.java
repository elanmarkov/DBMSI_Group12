package global;

public class EID extends RID {
	
	public EID(){
		super();
	}
	
	public EID(PageId pageno, int slotno) {
		super(pageno, slotno);
	}
	
}
