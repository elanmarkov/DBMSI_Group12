package iterator;

import global.Descriptor; 

public class Operand {
  public  FldSpec  symbol;
  public  String   string;
  public  int      integer;
  public  float    real;
  public  Descriptor desc;
}
